<?php
header('Content-Type: application/json');
$response = ['status' => 'error', 'message' => 'Error desconocido.'];

error_reporting(E_ALL); 
ini_set('display_errors', 1); 
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

$TEST_MODE = false; 
if (isset($_GET['test']) && $_GET['test'] === '1') {
    $TEST_MODE = true;
}

try {
    // 1. Recibir los datos JSON de JavaScript
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);

    if ($data === null) {
        throw new Exception("Datos JSON no válidos.");
    }

    // 2. Extraer los datos y VALIDAR CORREO 
    $nombre = $data['name'] ?? 'N/A';
    $correo_participante = $data['email'] ?? ''; 
    $telefono = $data['phone'] ?? 'N/A';
    $answers = $data['answers'] ?? []; 
    $dominio_hostinger = 'faseuno.pro'; 
    $correo_notificaciones = 'noreply@' . $dominio_hostinger; 

    if (!filter_var($correo_participante, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("El correo proporcionado no es válido.");
    }
    
    // 3. Crear el Cuerpo del Mensaje
    
    $correo_contacto = 'faseunocontacto@gmail.com'; 
    
    $destinatarios = $correo_participante;
    
    
    $asunto = 'RESULTADOS DIAGNÓSTICO: ' . $nombre;
    
    // Calcular puntuación desde las respuestas
    $rawScore = 0;
    foreach ($answers as $qId => $answerValue) {
        if (is_array($answerValue)) {
            $v = isset($answerValue['value']) ? floatval($answerValue['value']) : 0;
        } else {
            $v = is_numeric($answerValue) ? floatval($answerValue) : 0;
        }
        $rawScore += $v;
    }

    // Máximo teórico: 150 puntos
    $MAX_THEORETICAL_SCORE = 150;
    $totalScore = ($MAX_THEORETICAL_SCORE > 0) ? min(100, (int) round(($rawScore / $MAX_THEORETICAL_SCORE) * 100)) : 0;

    // --- 3.5. CÁLCULO DEL DESGLOSE POR ÁREA ---
    // Estructura que mapea IDs de preguntas (o bloques) a Nombres de Área y Puntuaciones Máximas
    // (ESTA ES UNA ESTRUCTURA EJEMPLO, AJUSTA LOS VALORES SEGÚN TU QUIZ REAL)
    $BLOCK_CONFIG = [
        'Bloque 1: Estrategia & Objetivos' => ['1', '2', '3', '4', '5'], 
        'Bloque 2: Modelo de Negocio' => ['6', '7', '8', '9', '10'], 
        'Bloque 3: Producto & Desarrollo' => ['11', '12','13', '14', '15'], 
        'Bloque 4: Operaciones & Procesos' => ['16', '17', '18', '19', '20'], 
        'Bloque 5: Ventas & Marketing' => ['21', '22', '23', '24', '25'], 
        'Bloque 6: Capacidad & Ejecución' => ['26', '27', '28', '29', '30'],
    ];
    // Puntuación máxima por bloque 
    $MAX_SCORE_PER_BLOCK = 25; 

    $blockBreakdown = [];
    foreach ($BLOCK_CONFIG as $blockName => $qIds) {
        $blockScore = 0;
        foreach ($qIds as $qId) {
            $answerValue = $answers[$qId] ?? 0;
            $v = is_array($answerValue) ? (floatval($answerValue['value'] ?? 0)) : (floatval($answerValue));
            $blockScore += $v;
        }

        $percentage = ($MAX_SCORE_PER_BLOCK > 0) ? min(100, (int) round(($blockScore / $MAX_SCORE_PER_BLOCK) * 100)) : 0;

        $blockBreakdown[$blockName] = [
            'score' => $blockScore,
            'percentage' => $percentage,
        ];
    }

    // Rangos de madurez y recomendaciones
    $MATURITY_RANGES = [
        ['max' => 20, 'level' => 'IDEA CONFUSA 🤔', 'recommendations' => ["Enfócate en definir mejor tu Propuesta de Valor única (PVU).", "Identifica tu nicho de cliente exacto, no de forma genérica, lo más detallado posible.", "No construyas nada aún, ¡solo habla con usuarios! Enfócate en preguntar y escuchar atentamente."]],
        ['max' => 40, 'level' => 'EN VALIDACIÓN 🔬', 'recommendations' => ["Crea una Landing Page de prueba rápida. No necesitas una web sólo una interfase accionable.", "Contacta a potenciales clientes o lanza anuncios de bajo presupuesto para medir interés.", "Realiza entrevistas centradas en el problema (no en el producto o la solución)."]],
        ['max' => 60, 'level' => 'MVP LISTO 🏗️', 'recommendations' => ["Crea y lanza una versión mínima (MVP) del producto para comenzar a interactuar con un grupo reducido de usuarios.", "Establece métricas de uso y conversión (ej: Tasa de Retención). Analiza resultados honestamente y ajusta.", "Necesitas saber si es un negocio viable. Calcula el Costo de Adquisición de Clientes (CAC)."]],
        ['max' => 80, 'level' => 'STARTUP EN TRACCIÓN 📈', 'recommendations' => ["Optimiza tu proceso de ventas/conversión. Enfócate en validar un embudo de ventas y luego automatizarlo.", "Busca canales de adquisición escalables y rentables. Debes testear variantes hasta que encuentres la que funcione para ti.", "Documenta procesos operativos para duplicar el crecimiento."]],
        ['max' => 100, 'level' => 'STARTUP CRECIENDO 🔥', 'recommendations' => ["Explora nuevos mercados. alianzas o segmentos de cliente.", "Invierte en automatización y desarrollo de equipos. Es momento de elegir bien tus palancas de negocio.", "Prepara tu empresa para una ronda de inversión. Optimiza tu pitch, crea campañas orientadas a comunicar el valor entregado, y alineadas a lo que un potencial inversor esperaría ver."]]
    ];

    $selectedRange = null;
    foreach ($MATURITY_RANGES as $r) {
        if ($totalScore <= $r['max']) { 
            $selectedRange = $r; 
            break; 
        }
    }
    if (!$selectedRange) { 
        $selectedRange = end($MATURITY_RANGES); 
    }

    // Construir cuerpo del mensaje: texto plano y HTML 
    $plain_body = "--- Datos del Contacto ---\n";
    $plain_body .= "Nombre: " . $nombre . "\n";
    $plain_body .= "Correo: " . $correo_participante . "\n";
    $plain_body .= "Teléfono: " . $telefono . "\n\n";
    $plain_body .= "--- Nivel de Madurez ---\n";
    $plain_body .= "Nivel: " . $selectedRange['level'] . "\n";
    $plain_body .= "Puntuación: " . $totalScore . "/100\n\n";
    $plain_body .= "--- Respuestas del Quiz ---\n";
    foreach ($answers as $qId => $answerValue) {
        if (is_array($answerValue)) {
            $display = $answerValue['label'] ?? $answerValue['value'] ?? json_encode($answerValue);
        } else {
            $display = $answerValue;
        }
        $plain_body .= "Pregunta ID {$qId}: Respuesta ({$display})\n";
    }

    // HTML body: estructura con tabla y estilos inline para mejor compatibilidad
    $html_body = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    $html_body .= '<style>
    body{font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Ubuntu, Arial, Helvetica, sans-serif; color: #111; background: #f7f7f8; margin: 0; padding: 20px} 
    .card{max-width: 700px; margin: 0 auto; background: #ffffff; border-radius: 8px;box-shadow: 0 2px 12px rgba(16,24,40,0.08); overflow: hidden} 
    .header{background: linear-gradient (90deg, #5c24b8, #b18deb); padding: 24px 24px; color: #fff; display: flex; align-items: center;} 
    .header h1{margin: 0; font-size: 26px; font-weight: 700; margin-left: 12px; line-height: 1.2;} 
    .logo{height: 35px; margin-bottom: 8px;} 
    .content{padding: 20px; color: #111} 
    table{width: 100%; border-collapse: collapse; margin-top: 10px} 
    th,td{padding: 8px 10px; text-align: left; border-bottom: 1px solid #eee; font-size: 14px} 
    th{background: #fafafa; color: #333; font-weight: 700} 
    .muted{color: #6b7280; font-size: 13px} 
    .footer-note{padding: 14px 20px; background: #fafafa; font-size: 13px; color: #6b7280; text-align: center}
    </style>';
    $html_body .= '</head><body>';
    $html_body .= '<div class="card">';
    $html_body .= '<div class="header">';
    $html_body .= '<img src="https://faseuno.pro/icons/logos_fase_uno_definitivo.png" alt="Logo Fase Uno" class="logo" style="height:28px; display:block;">';
    $html_body .= '<h1>Resultado del Diagnóstico — Fase Uno</h1>';
    $html_body .= '</div>';
    $html_body .= '<div class="content">';
    $html_body .= '<p class="muted">A continuación se incluyen los datos de tu diagnóstico y el detalle de las respuestas proporcionadas del quiz.</p>';

    // Informacion de contacto de la tabla
    $html_body .= '<table aria-label="Datos de contacto"><tr><th>Campo</th><th>Valor</th></tr>';
    $html_body .= '<tr><td>Nombre</td><td>' . htmlspecialchars($nombre) . '</td></tr>';
    $html_body .= '<tr><td>Correo</td><td>' . htmlspecialchars($correo_participante) . '</td></tr>';
    $html_body .= '<tr><td>Teléfono</td><td>' . htmlspecialchars($telefono) . '</td></tr>';
    $html_body .= '</table>';

    // Bloque de Diagnóstico 
    $html_body .= '<div style="margin-top:20px;padding:16px;background:#f9f9ff;border:1px solid #e0e0f0;border-left:5px solid #5c24b8;border-radius:6px;">';
    $html_body .= '<h3 style="margin:0 0 8px 0;color:#5c24b8;font-size:16px;font-weight:700;">Nivel de Madurez Actual</h3>';
    $html_body .= '<p style="margin:0;color:#111;font-size:18px;font-weight:700;">' . htmlspecialchars($selectedRange['level']) . '</p>';
    $html_body .= '<p style="margin:8px 0 0 0;color:#333;font-size:14px;">Puntuación: <strong style="color:#5c24b8;">' . $totalScore . '</strong>/100</p>';
    $html_body .= '</div>';

    //  Desglose por area
    $html_body .= '<h3 style="margin-top:24px;margin-bottom:8px;color:#5c24b8;font-size:16px;font-weight:700;border-bottom:1px solid #eee;padding-bottom:6px;">Desglose por Área</h3>';
    $html_body .= '<table aria-label="Desglose por área" style="margin-top:0;">';
    
    foreach ($blockBreakdown as $blockName => $data) {
        $percentage = $data['percentage'];
        
        // Estilos para la barra de progreso 
        $barColor = '#b18deb';
        if ($percentage >= 80) $barColor = '#5cb85c'; 
        elseif ($percentage >= 50) $barColor = '#f0ad4e'; 
        else $barColor = '#d9534f';
        
        $html_body .= '<tr>';
        $html_body .= '<td colspan="3" style="padding: 12px 10px; border-bottom: 1px solid #eee;">';
        // 1. Nombre del Bloque
        $html_body .= '<p style="margin: 0 0 8px 0; font-weight: 700; color: #333; font-size: 15px;">' . htmlspecialchars($blockName) . '</p>';
        // 2. Contenedor de la Barra de Progreso y el Porcentaje (usando una tabla interna para alineación)
        $html_body .= '<table style="width:100%; border-collapse:collapse; margin: 0; padding: 0;"><tr>';

        // Columna de la Barra
        $html_body .= '<td style="width: 80%; padding: 0; border: none;">';
        $html_body .= '<div style="background:#eeeeee; height:10px; border-radius:5px; overflow:hidden;">';
        $html_body .= '<div style="width:' . $percentage . '%; background:' . $barColor . '; height:100%; border-radius:5px;"></div>';
        $html_body .= '</div>';
        $html_body .= '</td>';
        
        // Columna del Porcentaje
        $html_body .= '<td style="width: 20%; padding: 0 0 0 10px; text-align: right; border: none; font-weight: 700; color:' . $barColor . '; font-size: 14px;">';
        $html_body .= $percentage . '%';
        $html_body .= '</td>';
        $html_body .= '</tr></table>';
        $html_body .= '</td>';
        $html_body .= '</tr>';
    }
    $html_body .= '</table>';

    // Bloque de Recomendaciones
    $html_body .= '<div style="margin-top:20px;">';
    $html_body .= '<h3 style="margin:0 0 12px 0;color:#5c24b8;font-size:16px;font-weight:700;border-bottom:1px solid #eee;padding-bottom:6px;">Recomendaciones Iniciales</h3>';
    foreach ($selectedRange['recommendations'] as $rec) {
        $html_body .= '<div style="margin-bottom:10px;padding:12px;background:#ffffff;border:1px solid #e0e0f0;border-left:4px solid #5c24b8;border-radius:3px;color:#111;font-size:14px;">' . htmlspecialchars($rec) . '</div>';
    }
    $html_body .= '</div>';

    // // Bloque de Diagnóstico  2

    // $html_body .= '<div style="margin-top:20px;padding:16px;background:#f9f9ff;border:1px solid #e0e0f0;border-left:5px solid #5c24b8;border-radius:6px;">';
    // $html_body .= '<h3 style="margin:0 0 8px 0;color:#5c24b8;font-size:16px;font-weight:700;">Nivel de Madurez Actual</h3>';
    // $html_body .= '<p style="margin:0;color:#111;font-size:18px;font-weight:700;">' . htmlspecialchars($selectedRange['level']) . '</p>';
    // $html_body .= '<p style="margin:8px 0 0 0;color:#333;font-size:14px;">Puntuación: <strong style="color:#5c24b8;">' . $totalScore . '</strong>/100</p>';
    // $html_body .= '</div>';

    // // Bloque de Recomendaciones 2
    // $html_body .= '<div style="margin-top:20px;">';
    // $html_body .= '<h3 style="margin:0 0 12px 0;color:#5c24b8;font-size:16px;font-weight:700;border-bottom:1px solid #eee;padding-bottom:6px;">Recomendaciones Iniciales</h3>';
    // foreach ($selectedRange['recommendations'] as $rec) {
    //     $html_body .= '<div style="margin-bottom:10px;padding:12px;background:#ffffff;border:1px solid #e0e0f0;border-left:4px solid #5c24b8;border-radius:3px;color:#111;font-size:14px;">' . htmlspecialchars($rec) . '</div>';
    // }
    // $html_body .= '</div>';

    // Tabla de respuestas
    // $html_body .= '<h3 style="margin-top:18px;margin-bottom:8px;color:#5c24b8;">Respuestas del Quiz</h3>';
    // $html_body .= '<table aria-label="Respuestas del quiz"><tr><th>Pregunta ID</th><th>Respuesta</th></tr>';
    // foreach ($answers as $qId => $answerValue) {
    //     if (is_array($answerValue)) {
    //         $display = htmlspecialchars($answerValue['label'] ?? $answerValue['value'] ?? json_encode($answerValue));
    //     } else {
    //         $display = htmlspecialchars($answerValue);
    //     }
    //     $html_body .= '<tr><td>' . htmlspecialchars($qId) . '</td><td>' . $display . '</td></tr>';
    // }
    // $html_body .= '</table>';

    $html_body .= '<p class="muted" style="margin-top:16px">Reserva tu <strong>mentoría gratuita</strong> y habla con un experto sobre cómo llevar tu proyecto al siguiente nivel. <a href="https://faseuno.pro/agendar/" style="color:#5c24b8;text-decoration:none">Aquí</a>.</p>';
    $html_body .= '</div>'; 
    $html_body .= '<div class="footer-note">Fase Uno — Diagnóstico de Madurez • © ' . date('Y') . ' Fase Uno Startup Studio</div>';
    $html_body .= '</div></body></html>';

    // 4. Enviar el correo
    $cabeceras = "From: {$correo_notificaciones}\r\n";
    $cabeceras .= "Reply-To: {$correo_notificaciones}\r\n";
    $cabeceras .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $cabeceras .= "MIME-Version: 1.0\r\n";
    // Copia oculta al correo de contacto
    $cabeceras .= "Bcc: {$correo_contacto}\r\n";

    // CONFIGURACIÓN SMTP - PHPMailer
    $smtp_host = 'smtp.hostinger.com';
    $smtp_port = 587;
    $smtp_user = $correo_notificaciones; 
    $smtp_password = 'Kontrasenia2025!'; 
    $smtp_secure = 'tls'; 
    $log_file = __DIR__ . '/mail_debug.log';

    // Si estamos en modo de prueba, devolvemos el contenido del correo y no intentamos enviarlo
    if ($TEST_MODE) {
        $response['status'] = 'test';
        $response['message'] = 'TEST_MODE activo: no se envía correo.';
        $response['email_preview'] = [
            'from' => $correo_notificaciones,
            'to' => $destinatarios,
            'bcc' => $correo_contacto,
            'subject' => $asunto,
            'plain' => $plain_body,
            'html' => $html_body,
            'raw_json' => $json_data,
        ];
        echo json_encode($response);
        exit;
    }

    // Enviar con PHPMailer+SMTP
    error_log("Intentando enviar correo a: {$destinatarios} (BCC: {$correo_contacto})", 3, $log_file);

    require_once __DIR__ . '/vendor/autoload.php';
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $smtp_host;
        $mail->SMTPAuth = true;
        $mail->Username = $smtp_user;
        $mail->Password = $smtp_password;
        $mail->SMTPSecure = $smtp_secure;
        $mail->Port = $smtp_port;
        $mail->CharSet = 'UTF-8';

        // Remitente
        $mail->setFrom($smtp_user, 'Quiz Notificaciones');
        
        // Destinatario principal (participante)
        if (!empty($correo_participante)) {
            $mail->addAddress($correo_participante);
        }
        
        // Copia oculta al contacto
        if (!empty($correo_contacto)) {
            $mail->addBCC($correo_contacto);
        }

        // Contenido (HTML + texto plano)
        $mail->isHTML(true);
        $mail->Subject = $asunto;
        $mail->Body = $html_body;
        $mail->AltBody = $plain_body;

        // Enviar
        $mail->send();
        
        error_log("PHPMailer envió el correo a {$correo_participante} (BCC: {$correo_contacto})", 3, $log_file);
        $response['status'] = 'success';
        $response['message'] = 'Datos procesados y resultados enviados.';
        
    } catch (Exception $e) {
        error_log('PHPMailer error: ' . ($mail->ErrorInfo ?? $e->getMessage()), 3, $log_file);
        throw new Exception('Error al enviar el correo: ' . ($mail->ErrorInfo ?? $e->getMessage()));
    }

} catch (Exception $e) {
    $response['message'] = 'Error en el servidor: ' . $e->getMessage();
}

// 5. Imprimir la respuesta JSON y finalizar la ejecución
echo json_encode($response);
exit;
?>